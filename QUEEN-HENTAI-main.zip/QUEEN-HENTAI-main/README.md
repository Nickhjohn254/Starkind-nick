# 💝 QUEEN HENTAI (18+ Adult Video Downloader And More Features) Bot 💝

<p align="center">
 <a href="#"><img title="QUEEN HENTAI" src="https://img.shields.io/badge/Whatshapp BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/dinuwah"><img title="Author" src="https://img.shields.io/badge/CREATOR-Dinuwa Official²⁰²³-green.svg?style=for-the-badge&logo=github"></a>

---------

  
<p align="center">  
  <a href="https://chat.whatsapp.com/Jyjqx7KBfgjDC7QcefHB1S">
    <img alt=Support height="300" src="https://i.imgur.com/bFEC7lC.jpeg">
   
</a> 
    
</p>
<p align="center">
<a 

####  
QUEEN HENTAI Multi Device 18+ Adult Video Downloader Whatsapp Bot.

***



1. 🇱🇰 Fork Queen Hentai Git 🇱🇰
    <br>
<a href='https://github.com/dinuwah/QUEEN-HENTAI' target="_blank"><img alt='💝Fork Repo💝' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=red'/></a>

2. Scan The QR And Upload dinuwa.data.json To Your Fork (Will Recieve It On Your Bot Number After Scanning)
    <br>
<a href='https://replit.com/@kafodip563/QUEEN-HENTAI-QR-CODE-GENERATOR?v=1' target="_blank"><img alt='💝SCAN QR💝' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=red'/></a>

### a little about this bot
- ✔️ | **Simple** 
- ✔️ | **18+ Adult Video Downloader** 
- ✔️ | **Multi Device** 
- ✔️ | **Button Document(Experiment)** 
---------

## ``Support Group``
[![WHATSAPP](https://img.shields.io/badge/Support%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/Jyjqx7KBfgjDC7QcefHB1S) 
---------

## ```HEROKU DEPLOYMENT```

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/dinuwah/QUEEN-HENTAI)
---------

## ```HEROKU TUTORIAL```
[![Watch on YOUTUBE](https://img.shields.io/badge/youtube%20TUTORIAL-red?style=for-the-badge&logo=youtube)](https://youtu.be/udsSWHUyAy4) 
---------

## ```STEPS TO DEPLOY ON HEROKU```

- 1. Fork this repo (Don't forget to give a star)
- 2. ***Get [SESSION-ID](https://replit.com/@kafodip563/QUEEN-HENTAI-QR-CODE-GENERATOR?v=1) by scanning QR code. `Whatapp>Three dots>Linked Devices`***
- 3. Upload your session file.
- 4. Simply click Deploy to heroku button above

## ```QR SCAN```
# 

* [`1️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://replit.com/@kafodip563/QUEEN-HENTAI-QR-CODE-GENERATOR?v=1?output%20only=1&lite=1#thumbnail.jpg)
* [`2️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://replit.com/@kafodip563/QUEEN-HENTAI-QR-CODE-GENERATOR?v=1)
* [`3️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://replit.com/@kafodip563/QUEEN-HENTAI-QR-CODE-GENERATOR?v=1?output%20only=1&lite=1#thumbnail.jpg)  
---------
  
## DEPLOY IN KOYEB    
[![Deploy on Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/auth/signup)  

## ```DEPLOY IN RAILWAY```

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app)
  
## DEPLOY IN COOLIFY    
[![Deploy on COOLIFY](https://img.shields.io/badge/coolify%20Account-yellow?style=for-the-badge&logo=coolify)](http://65.21.52.72:3000/register)  

## ```DEPLOY IN REPLIT```
[![Run on Repl.it](https://repl.it/badge/github/dinuwah/QUEEN-HENTAI)](https://replit.com)

## ```DEPLOY IN MOGENIUS```
[![Deploy on Mogenius](https://telegra.ph/file/946d83b461457a3c1598c.png)](https://studio.mogenius.com/studio/cloud-space/cloud-space-overview)
  
## DEPLOY IN RENDER    
[![Deploy on RENDER](https://img.shields.io/badge/render%20Account-green?style=for-the-badge&logo=render)](https://dashboard.render.com/registerundefined)  


## Special Thanks To
- 1. 💭 Xeon ( cheems wa owner )
- 2. 💭 Guru ( guru wa owner )
- 3. 💭 Mr nima ( Elisa wa owner )
- 4. 💭 Abhishek ( Abhishek wa owner )
---------
