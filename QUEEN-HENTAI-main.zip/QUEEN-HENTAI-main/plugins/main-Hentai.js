let handler = async m => m.reply(`

   *💝 Queen Hentai 💝* WA Group
🔊 Join Public Bot Group And Support
https://chat.whatsapp.com/Jyjqx7KBfgjDC7QcefHB1S
─────────────
🔊 *Github*
https://github.com/dinuwah/QUEEN-HENTAI
 
🔊 *Contact*
wa.me:94767939688

🔊 *Instagram*
https://instagram.com/Dinuwa Official²⁰²³

`.trim())
handler.help = ['gphentai']
handler.tags = ['main']
handler.command = ['groups', 'supporthentai', 'hentaigp', 'grouphentai', 'group'] 

export default handler
